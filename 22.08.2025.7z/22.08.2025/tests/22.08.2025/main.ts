import { ProductFactory } from './ProductFactory';

const product = ProductFactory.createSmartphoneXYZ();
console.log(JSON.stringify(product, null, 2));





