ProductFactory.ts

import { ProductBuilder } from './ProductBuilder';
import { Product } from './types';

export class ProductFactory {
  static createSmartphoneXYZ(): Product {
    const builder = new ProductBuilder();

    return builder
      .setBasicInfo(
        12345,
        "Smartphone XYZ",
        true,
        99900,
        999.99,
        "High-quality smartphone with advanced features",
        null
      )
      .setWarranty({
        years: 2,
        type: "limited",
        coverage: ["hardware", "software", "battery"]
      })
      .setTimestamps(
        new Date("2024-08-21T10:30:00.000Z"),
        new Date("2024-08-21T12:15:30.000Z")
      )
      .setTags(["electronics", "mobile", "smartphone", "5G", "premium"])
      .setReviews([
        {
          id: 1,
          rating: 5,
          comment: "Excellent product! Fast delivery and great quality",
          reviewer: "John Doe",
          reviewerEmail: "john.doe@example.com",
          date: "2024-01-15T14:20:00.000Z",
          verified: true,
          helpful: 45
        },
        {
          id: 2,
          rating: 4,
          comment: "Good value for money, battery could be better",
          reviewer: "Jane Smith",
          reviewerEmail: "jane.smith@example.com",
          date: "2024-02-20T09:45:00.000Z",
          verified: true,
          helpful: 32
        },
        {
          id: 3,
          rating: 5,
          comment: "Amazing camera quality and performance",
          reviewer: "Mike Johnson",
          reviewerEmail: "mike.johnson@example.com",
          date: "2024-03-10T16:30:00.000Z",
          verified: false,
          helpful: 18
        }
      ])
      .setSpecifications({
        processor: "Snapdragon 8 Gen 2",
        memory: "8GB RAM",
        storage: "256GB",
        display: "6.7 inch OLED",
        camera: "50MP triple camera",
        battery: "4500mAh",
        os: "Android 14",
        connectivity: ["5G", "WiFi 6E", "Bluetooth 5.3", "NFC"]
      })
      .setCategories(["electronics", "smartphones", "premium"])
      .setPricing({
        original: 99900,
        current: 89900,
        discount: 10,
        currency: "USD",
        tax: 8.5
      })
      .setInventory({
        stock: 150,
        reserved: 25,
        available: 125,
        reorderLevel: 50,
        supplier: "TechCorp Ltd",
        nextDelivery: "2024-12-01T00:00:00.000Z"
      })
      .setShipping({
        weight: 0.18,
        dimensions: {
          length: 15.5,
          width: 7.5,
          height: 0.8
        },
        freeShipping: true,
        estimatedDays: 2,
        shippingMethods: ["standard", "express", "overnight"]
      })
      .setSEO({
        title: "Smartphone XYZ - Premium 5G Mobile Phone",
        description: "Experience the latest technology with our premium smartphone featuring advanced camera, long battery life, and 5G connectivity.",
        keywords: ["smartphone", "5G", "premium", "camera", "android"],
        slug: "smartphone-xyz-premium-5g"
      })
      .setAnalytics({
        views: 15420,
        purchases: 847,
        conversionRate: 5.5,
        averageRating: 4.7,
        totalReviews: 243
      })
      .build();
  }
}
