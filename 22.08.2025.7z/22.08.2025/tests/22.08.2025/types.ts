types.ts

export interface Warranty {
  years: number;
  type: string;
  coverage: string[];
}

export interface Review {
  id: number;
  rating: number;
  comment: string;
  reviewer: string;
  reviewerEmail: string;
  date: string;
  verified: boolean;
  helpful: number;
}

export interface Specifications {
  processor: string;
  memory: string;
  storage: string;
  display: string;
  camera: string;
  battery: string;
  os: string;
  connectivity: string[];
}

export interface Pricing {
  original: number;
  current: number;
  discount: number;
  currency: string;
  tax: number;
}

export interface Inventory {
  stock: number;
  reserved: number;
  available: number;
  reorderLevel: number;
  supplier: string;
  nextDelivery: string;
}

export interface Shipping {
  weight: number;
  dimensions: {
    length: number;
    width: number;
    height: number;
  };
  freeShipping: boolean;
  estimatedDays: number;
  shippingMethods: string[];
}

export interface SEO {
  title: string;
  description: string;
  keywords: string[];
  slug: string;
}

export interface Analytics {
  views: number;
  purchases: number;
  conversionRate: number;
  averageRating: number;
  totalReviews: number;
}

export interface Product {
  id: number;
  name: string;
  isAvailable: boolean;
  price: number;
  priceFloat: number;
  description: string;
  manufacturer: string | null;
  warranty?: Warranty;
  createdAt?: string;
  updatedAt?: string;
  tags?: string[];
  reviews?: Review[];
  specifications?: Specifications;
  categories?: string[];
  pricing?: Pricing;
  inventory?: Inventory;
  shipping?: Shipping;
  seo?: SEO;
  analytics?: Analytics;
}
