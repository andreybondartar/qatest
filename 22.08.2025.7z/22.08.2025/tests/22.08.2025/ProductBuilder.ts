ProductBuilder.ts

import { Product, Warranty, Review, Specifications, Pricing, Inventory, Shipping, SEO, Analytics } from './types';

export class ProductBuilder {
  private product: Product;

  constructor() {
    this.product = {} as Product;
  }

  setBasicInfo(id: number, name: string, isAvailable: boolean, price: number, priceFloat: number, description: string, manufacturer: string | null): this {
    this.product.id = id;
    this.product.name = name;
    this.product.isAvailable = isAvailable;
    this.product.price = price;
    this.product.priceFloat = priceFloat;
    this.product.description = description;
    this.product.manufacturer = manufacturer;
    return this;
  }

  setWarranty(warranty: Warranty): this {
    this.product.warranty = warranty;
    return this;
  }

  setTimestamps(createdAt: Date, updatedAt: Date): this {
    this.product.createdAt = createdAt.toISOString();
    this.product.updatedAt = updatedAt.toISOString();
    return this;
  }

  setTags(tags: string[]): this {
    this.product.tags = tags;
    return this;
  }

  setReviews(reviews: Review[]): this {
    this.product.reviews = reviews;
    return this;
  }

  setSpecifications(specs: Specifications): this {
    this.product.specifications = specs;
    return this;
  }

  setCategories(categories: string[]): this {
    this.product.categories = categories;
    return this;
  }

  setPricing(pricing: Pricing): this {
    this.product.pricing = pricing;
    return this;
  }

  setInventory(inventory: Inventory): this {
    this.product.inventory = inventory;
    return this;
  }

  setShipping(shipping: Shipping): this {
    this.product.shipping = shipping;
    return this;
  }

  setSEO(seo: SEO): this {
    this.product.seo = seo;
    return this;
  }

  setAnalytics(analytics: Analytics): this {
    this.product.analytics = analytics;
    return this;
  }

  build(): Product {
    return this.product;
  }
}
