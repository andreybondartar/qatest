import { APIRequestContext } from "@playwright/test";

export class Auth {

request: APIRequestContext

constructor(request: APIRequestContext) {

   this.request = request; 
   if(!this.isCredentialsExist()){
    throw new Error('Some of env variable are not exist')
   }

}


isCredentialsExist() 



async getAndSaveToken() {

  const response = await this.request.post(
    "https://accounts.spotify.com/api/token",
    {
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        Authorization:
          "Basic " +
          Buffer.from(
            `${process.env.SPOTIFY_CLIENT_ID}:${process.env.SPOTIFY_CLIENT_SECRET}`
          ).toString("base64"),
      },
      params: {
        grant_type: "authorization_code",
        code: process.env.AUTHORIZATION_CODE,
        redirect_uri: process.env.REDIRECT_URL,
      },
    }
  );

  const fullTokens = await response.json();

  writeFileSync("tokens.json", JSON.stringify(fullTokens));

  console.log(fullTokens);

  return fullTokens;
}
}